﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF
{
    /// <summary>
    /// Interaction logic for ListViews.xaml
    /// </summary>
    public partial class ListViews : Window
    {
        public ListViews()
        {
            InitializeComponent();

            List<Game> games = new List<Game>();
            games.Add(new Game("Black Ops", "Capcom", 2010));
            games.Add(new Game("Pokemon Black", "Freak", 2006));
            games.Add(new Game("Mario Party", "Some company", 2005));

            lstGames.ItemsSource = games;

            lstGamesBind.ItemsSource = games;

            lstGameColumns.ItemsSource = games;
        }

        class Game
        {
            public string Name { get; set; }
            public string Company { get; set; }
            public int Year { get; set; }

            public Game(string name, string company, int year)
            {
                Name = name;
                Company = company;
                Year = year;
            }

            public override string ToString()
            {
                return Name + " " + Company + " " + Year;
            }
        }
    }
}
