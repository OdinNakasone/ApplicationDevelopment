﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF
{
    /// <summary>
    /// Interaction logic for Resources.xaml
    /// </summary>
    public partial class Resources : Window
    {
        public Resources()
        {
            InitializeComponent();

            txtResource.Text = this.FindResource("CompanyName").ToString();
            txtResource.Text = Application.Current.FindResource("AppString").ToString();
   
        }

        private void btnColorChange_Click(object sender, RoutedEventArgs e)
        {
            Resources["CompanyColor"] = new SolidColorBrush(Colors.Purple);
        }
    }
}
