﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF
{
    /// <summary>
    /// Interaction logic for DataBinding.xaml
    /// </summary>
    public partial class DataBinding : Window
    {

        ObservableCollection<Student> students = new ObservableCollection<Student>();
        public DataBinding()
        {
            InitializeComponent();

            DataContext = this;

            Binding binding = new Binding("Text");
            binding.Source = txtEntry;
            txtData.SetBinding(TextBlock.TextProperty, binding);

            students.Add(new Student() { Name="Tim", ID = 1});
            students.Add(new Student() { Name="Jim", ID = 2});
            students.Add(new Student() { Name="Kim", ID = 3});

            lstStudents.ItemsSource = students;
        }

        private void UpdateSource_Click(object sender, RoutedEventArgs e)
        {
            BindingExpression binding = txtTitle.GetBindingExpression(TextBox.TextProperty);
            binding.UpdateSource();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            students.Add(new Student() { Name = "Sim", ID = 4 });
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            if(lstStudents.SelectedItem != null)
            {
                students.Remove((Student)lstStudents.SelectedItem);
            }
        }

        private void btnChange_Click(object sender, RoutedEventArgs e)
        {
            if (lstStudents.SelectedItem != null)
            {
                ((Student)lstStudents.SelectedItem).Name = "New Name";
            }
        }
    }

    public class Student : INotifyPropertyChanged
    {
        string name;
        public String Name 
        {
            get { return name; } 
            set
            {
                if(value != name)
                {
                    name = value;
                    OnPropertyChanged();
                }
            }
        }
        public int ID { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    class StringToBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (value.ToString().ToLower() == "yes");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value is bool bvalue)
            {
                return (bvalue) ? "yes" : "no";
            }

            return "no";
        }
    }
}
