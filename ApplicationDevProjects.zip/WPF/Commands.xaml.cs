﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF
{
    /// <summary>
    /// Interaction logic for Commands.xaml
    /// </summary>
    public partial class Commands : Window
    {
        public Commands()
        {
            InitializeComponent();
        }

        private void NewCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void NewCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("New Command", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SubmitCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = txtName.Text.Length > 0;
        }

        private void SubmitCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("Submit", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    public static class CustomCommands
    {
        public static readonly RoutedUICommand Submit = new RoutedUICommand
            (
                "Submit",
                "submit",
                typeof(CustomCommands),
                new InputGestureCollection() { new KeyGesture(Key.S, ModifierKeys.Alt)}
            );
    }
}
