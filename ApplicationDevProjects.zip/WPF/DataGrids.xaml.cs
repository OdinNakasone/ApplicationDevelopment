﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF
{
    /// <summary>
    /// Interaction logic for DataGrids.xaml
    /// </summary>
    public partial class DataGrids : Window
    {
        public DataGrids()
        {
            InitializeComponent();

            List<Game> games = new List<Game>();
            games.Add(new Game("Black Ops", "Capcom", new DateTime(2010, 1, 1), "https://s7d9.scene7.com/is/image/Mattel/GRN44_Courtneys_PACMAN_Arcade_Game_01?fit=constrain,1&wid=2000&hei=2000&fmt=jpg"));
            games.Add(new Game("Pokemon Black", "Freak", new DateTime(2006, 1, 1), "https://s7d9.scene7.com/is/image/Mattel/GRN44_Courtneys_PACMAN_Arcade_Game_01?fit=constrain,1&wid=2000&hei=2000&fmt=jpg"));
            games.Add(new Game("Mario Party", "Some company", new DateTime(2008, 1, 1), "https://s7d9.scene7.com/is/image/Mattel/GRN44_Courtneys_PACMAN_Arcade_Game_01?fit=constrain,1&wid=2000&hei=2000&fmt=jpg", true));

            dgdGames.ItemsSource = games;

        }

        class Game
        {
            public string Name { get; set; }
            public string Company { get; set; }
            public DateTime Release { get; set; }

            public bool IsAvailable { get; set; }

            public string URL { get; set; }

            public Game(string name, string company, DateTime release, string url, bool isAvailable = false)
            {
                Name = name;
                Company = company;
                Release = release;
                URL = url;
                IsAvailable = isAvailable;
            }

            public override string ToString()
            {
                return Name + " " + Company + " " + Release;
            }
            public string  Info
            {
                get { return Name + " " + Company + " " + Release; }
            }
        }
    }
}
