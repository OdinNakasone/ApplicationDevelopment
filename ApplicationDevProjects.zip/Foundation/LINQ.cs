﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Foundation
{
    class LINQ
    {
        public static void Execute()
        {
            // 1) data source
            string[] people = { "Diana", "Clark", "Bruce", "Barry" };

            // 2) query creation
            //expression syntax (from, where, select)
            var result = from name in people
                         where name.Contains("r")
                         select name;

            people[0] = "rebecca";

            // 3) query execution
            foreach(var name in result)
            {
                Console.WriteLine(name);
            }

            //method syntax
            var methodResult = people
                .Where(name => name.Contains("a"))
                .Select(name => new { name, name.Length });

            foreach (var nameInfo in methodResult)
            {
                Console.WriteLine(nameInfo.name + " " + nameInfo.Length);
            }

            //take and skip
            var take = people.TakeWhile(name => name.Contains("i"));
            //var take = people.Take(2);
            foreach (var name in take)
            {
                Console.WriteLine(name);
            }


            var skip = people.SkipWhile(name => name.Contains("a"));
            //var skip = people.Skip(2);
            foreach (var name in skip)
            {
                Console.WriteLine(name);
            }

            // ordering
            int[] numbers = { 5, 10, 34, 12, 50 };
            var orderResult = from n in numbers
                              where n > 10
                              orderby n descending
                              select n;

            foreach(var number in orderResult)
            {
                Console.WriteLine(number + " ");
            }

            Console.WriteLine();

            List<Hero> heroes = new List<Hero>();
            heroes.Add(new Hero() { Name = "Superman", Age = 99, Power = Hero.ePower.Fly | Hero.ePower.Strength | Hero.ePower.Speed});
            heroes.Add(new Hero() { Name = "Wonder woman", Age = 30, Power = Hero.ePower.Strength});
            heroes.Add(new Hero() { Name = "Superman", Age = 45, Power = Hero.ePower.Fly | Hero.ePower.Strength});

            var heroResult = from hero in heroes
                             where hero.Age > 30
                             select hero.Name;
                             //select new { hero.Name, hero.Age};

            foreach(var hero in heroResult)
            {
                Console.WriteLine(hero + "|");
            }
            Console.WriteLine();

            // element operators
            var element = heroes.FirstOrDefault(hero => hero.Age < 40);
        }

        class Hero
        {
            public enum ePower
            {
                Fly          = 1 << 0,
                Strength     = 1 << 1,
                Speed        = 4 << 2
            }
            public string Name { get; set; }
            public int Age { get; set; }

            public ePower Power { get; set; }
        }
    }
}
