﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Anonymous
    {
        public delegate int TransformDelegate(int i);    
        public static void Execute()
        {
            //anonymous types
            var person1 = new { Name = "Odin", Age = 19 };
            Console.WriteLine("AnonymousType: " + person1);
            Console.WriteLine("AnonymousType (Name): " + person1.Name);
            Console.WriteLine("AnonymousType (Age):" + person1.Age);

            int Age = 23;
            var person2 = new { Name = "Coby", Age };
            Console.WriteLine("AnonymousType: " + person2);
            Console.WriteLine("AnonymousType (Name): " + person2.Name);
            Console.WriteLine("AnonymousType (Age):" + person2.Age);

            var people = new[]
            {
                new{Name = "Yaksh", Year = 2022},
                new{Name = "Kia", Year = 2021},
                new{Name = "Adam", Year = 2023}
            };

            foreach(var person in people)
            {
                Console.WriteLine(person);
            }
            //anonymous methods
            TransformDelegate transform;
            transform = Sqr;
            Console.WriteLine("Anonymous Method: " + transform(4));

            transform = delegate (int x) { return x + x; };
            Console.WriteLine("Anonymous Method: " + transform(9));

            transform = (x) => { return x * x * x; };
            Console.WriteLine("Anonymous Method (Lambda): " + transform(3));

            Console.WriteLine("Anonymous Method (Parameter): " + Operation(transform, 5));
            Console.WriteLine("Anonymous Method (Parameter): " + Operation((x) => { return x / 2; }, 12));

            int scalar = 3;
            transform = (x) => { return scalar * x; };
            Console.WriteLine("Anonymous Method: " + transform(8));
        }

        public static int Sqr(int v) { return v * v; }
        public static int Operation(TransformDelegate transform, int value) { return transform(value); }
    }
}
