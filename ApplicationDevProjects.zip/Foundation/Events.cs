﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Events
    {

        public static void Execute()
        {
            InputSystem inputSystem = new InputSystem();
            inputSystem.KeyDown += KeyDownHandler;
            inputSystem.Update();
        }

        static void KeyDownHandler(object sender, InputEventArgs e)
        {
            Console.WriteLine("...Keydown : {0}", e.Key);
        }
    }

    //public delegate void Notify();

    class InputEventArgs : EventArgs
    {
        public char Key { get; set; }
    }
    class InputSystem
    {
        public void Update()
        {
            Console.WriteLine("Press Key....");
            bool done = false;
            do
            {
              ConsoleKeyInfo info =  Console.ReadKey();
                InputEventArgs args = new InputEventArgs();
                args.Key = info.KeyChar;
                OnKeyDown(args);

                done = info.KeyChar == 'q';
            } while (!done);
        }
        public event EventHandler<InputEventArgs> KeyDown;

        protected virtual void OnKeyDown(InputEventArgs e)
        {
            KeyDown?.Invoke(this, e);
        }
    }
}
