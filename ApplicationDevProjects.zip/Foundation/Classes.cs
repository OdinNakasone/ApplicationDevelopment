﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Classes
    {
        public static void Execute()
        {
            float r = Math.pi;

            float radians = Math.DegToRed(90.0f);

            {
                Student s = new Student();
                s.Age = 25;
                Console.WriteLine("Student Age: {0}", s.Age);

                s.GPA = 4.2f;
                Console.WriteLine("Student GPA: {0}", s.GPA);

                Console.WriteLine("Student Cohort: {0}", s.Cohort);
            }
          

            Student s2 = new Student("Odin", 19, 3.5f, 35);

            Student.WriteNumStudents();
        }
    }

    class Student
    {
        //fields
        private string name;
        private int cohort = 34;
        private float gpa = 3;

        private static int numStudents = 0; //per class instance

        //protected

        //internal

        public int Age { get; set; }
        public float GPA 
        { 
            get { return gpa; } 
            set
            {
                if (value >= 0 && value <=4)
                {
                    gpa = value;
                }
            }
        }

        public int Cohort { get { return cohort; } }

        public Student()
        {
            numStudents++;
            Console.WriteLine("num students {0}", numStudents);
        }

        static Student()
        {
            numStudents = 0;
        }

        public Student(string name, int age, float gpa, int cohort = 34)
        {
            numStudents++;
            this.name = name;
            Age = age;
            GPA = gpa;
            this.cohort = cohort;
        }

        ~Student()
        {
            Console.WriteLine("Destroy");
            numStudents--;
        }

        public static void WriteNumStudents()
        {
            Console.WriteLine("num students {0}", numStudents);
        }
    }
    
    /// <summary>
    /// Helper Math Class
    /// </summary>
    static class Math
    {
       public const float pi = 3.1415f;

        public static float DegToRed(float degrees)
        {
            return degrees * (pi / 180.0f);
        }
    }
}
