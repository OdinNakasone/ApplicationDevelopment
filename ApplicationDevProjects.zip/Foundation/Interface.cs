﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
   interface IFly
    {
        void Fly();
    }

    interface IHunt
    {
        void Hunt() { Console.WriteLine("Yummy!!!"); }
    }
}
