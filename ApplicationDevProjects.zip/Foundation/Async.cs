﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Foundation
{
    class Async
    {
        public static void Execute()
        {
            Console.WriteLine("**START**");

            Task<int> task = ComplexAsync();
            var awaiter = task.GetAwaiter();
            awaiter.OnCompleted(() =>
            {
                int result = awaiter.GetResult();
                Console.WriteLine("ASync: " + result);
            }
            );
            Console.WriteLine("*********");
            Task.Delay(2000).Wait();
            int result = Complex();
            Console.WriteLine("Sync: " + result);
        }

        public static async Task ExecuteASync()
        {
            Console.WriteLine("** ASYNC START ** ");
            int result = await ComplexAsync();
            Console.WriteLine("*Async*: " + result);
        }

        static Task<int> ComplexAsync()
        {
            return Task.Run(() => Complex());
        }

        static int Complex()
        {
            double x = 2;

            for(int i = 0; i < 100000000; i++)
            {
                x += MathF.Sqrt((float)x) / i;
            }

            return (int)x;
        }
    }
}
