﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Tuples
    {
        public static void Execute()
        {
            var eric = ("Eric", 20);
            Console.WriteLine(eric.Item1);
            Console.WriteLine(eric.Item2);

            eric.Item2  = 21;

            (string, int) lacy = ("Lacy", 22);
            Console.WriteLine(lacy);

            Console.WriteLine(GetPerson());

            var tim = (Name: "Tim", Age: 23);
            Console.WriteLine("Name: " + tim.Name);
            Console.WriteLine("Age: " + tim.Age);

            //deconstruction
           (string name, int age) = GetPerson();
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Age: " + age);
        }

        public static (string , int) GetPerson()
        {
            return ("Fred", 26);
        }
    }
}
