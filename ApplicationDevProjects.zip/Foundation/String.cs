﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class String
    {
        public static void Execute()
        {
            string str = "This is a string.";
            Console.WriteLine(str);

            Console.WriteLine("Length: {0}", str.Length);
            Console.WriteLine("Contains: {0}", str.Contains("is"));
            Console.WriteLine("Contains: {0}", str.IndexOf("is"));

            Console.WriteLine("Remove: {0}", str.Remove(5, 3));
            Console.WriteLine("Replace: {0}", str.Replace("string", "sentence"));

            Console.WriteLine($"Interpolation: {str}\n\n");
            Console.WriteLine("Concatenate: " + str);   
            Console.WriteLine(@"Verbatim: C:\Users\Raymond");

            StringBuilder sb = new StringBuilder("This is a string builder.", 255);
            Console.WriteLine($"String Builder {sb}");
            Console.WriteLine($"String Builder (capacity) {sb.Capacity}");
            Console.WriteLine($"String Builder (length) {sb.Length}");

            sb.Append(" Cool right!");
            Console.WriteLine($"String Builder {sb}");
            sb.Replace("Cool" , "awesome");
            Console.WriteLine($"String Builder {sb}");

            Console.WriteLine("Currency: {0:c}", 29.99);
            Console.WriteLine("Decimal: {0:d4}", 65);
            Console.WriteLine("Fixed point: {0:f2}", 23.456763);
            Console.WriteLine("Percent: {0:p1}", 12.3);
            Console.WriteLine("Number: {0:n0}", 1234);

        }
    }
}
