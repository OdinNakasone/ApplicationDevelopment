﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Delegates
    {
        delegate int Transformer(int v);
        delegate void FuncDelegate();

        public static void Execute()
        {
            Transformer t = Sqr;
            //Transformer t = new Transformer(Sqr);
            Console.WriteLine(t.Invoke(5));

            int[] values = { 2, 3, 4 };
            Transform(values, Sqr);

            foreach(int value in values )
            {
                Console.WriteLine("{0} ", value);
            }

            Console.WriteLine();

            FuncDelegate func;
            func = Function1;
            func();

            func = Function2;
            func();

            func = null;
            func?.Invoke();

            Console.WriteLine("Multicast Delegate");
            func = Function1;
            func += Function2;
            func();
            
        }

        static void Transform(int[] values, Transformer transformer)
        {
            for (int i = 0; i < values.Length; i++)
            {
                values[i] = transformer(values[i]);
            }
        }

        static void Function1() => Console.WriteLine("Function 1");
        static void Function2() => Console.WriteLine("Function ");

        static int Sqr(int v) => v * v;
        static int Cube(int v) => v * v * v;
    }
}
