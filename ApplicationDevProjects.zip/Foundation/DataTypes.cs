﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class DataTypes
    {
       public static void Execute()
        {
            int integer = 10;
            Console.WriteLine("int (32-bits): {0}", integer);   
            Console.WriteLine("int min: {0}", int.MinValue);
            Console.WriteLine("int max: {0}", int.MaxValue);

            long longInteger = 10;
            Console.WriteLine("long (64-bits): {0}", longInteger);
            Console.WriteLine("long min: {0}", long.MinValue);
            Console.WriteLine("long max: {0}", long.MaxValue);

            float fp = 23.5f;
            Console.WriteLine("float (32-bits): {0}", fp);
            Console.WriteLine("float min: {0}", float.MinValue);
            Console.WriteLine("float max: {0}", float.MaxValue);

            double db = 65.5;
            Console.WriteLine("double (64-bits): {0}", db);
            Console.WriteLine("double min: {0}", double.MinValue);
            Console.WriteLine("double max: {0}", double.MaxValue);

            char c = 'R';
            Console.WriteLine("char: {0}", c);
            Console.WriteLine("isDigit: {0}", char.IsDigit(c));
            Console.WriteLine("isLetter: {0}", char.IsLetter(c));

            bool b = true;
            Console.WriteLine("bool: {0}", b);

            var value = db;
            Console.WriteLine("var type: {0}", value.GetType());

            string str = "300";
            int i = int.Parse(str);
            Console.WriteLine("parse: {0}", i);
        }
    }
}
