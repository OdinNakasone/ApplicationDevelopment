﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Parameters
    {
        public static void Execute()
        {
            int i = 20;

            Func(i);
            Console.WriteLine("i: {0}", i);

            RefFunc(ref i);
            Console.WriteLine("i: {0}", i);

            int i1 = 23;
            int i2 = 46;

            Swap(ref i1, ref i2);
            Console.WriteLine("swap: {0} - {1}", i1, i2);

            //int i3 = 0;
            OutFunc(out int i3);
            Console.WriteLine("i3: {0}", i3);

            int.TryParse("100", out int result);
            Console.WriteLine("result: {0}", result);

            NamedFunc(y: 24, x: 12);
        }

        static void Func(int n)
        {
            n = n + 1;
            Console.WriteLine("Func: {0}", n);
        }

        static void RefFunc(ref int n)
        {
            n = n + 1;
            Console.WriteLine("Ref Func: {0}", n);
        }

        static void Swap(ref int lhs, ref int rhs)
        {
            int temp = lhs;
            lhs = rhs;
            rhs = temp;
        }
        static void OutFunc(out int n)
        {
            n = 10;
            Console.WriteLine("Out Func: {0}", n);  
        }   

        static void NamedFunc(int x, int y)
        {
            Console.WriteLine("x {0} - y {1}", x, y);
        }
    }
}
