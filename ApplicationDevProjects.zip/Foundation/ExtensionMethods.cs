﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class ExtensionMethods
    {

        public static void Execute()
        {
            int i1 = 5;
            Console.WriteLine("Sqr {0} ", i1.Sqr());

            string s = "hello";
            s = s.Pluralize();
            Console.WriteLine(s);
            Console.WriteLine(s.IsCapitalized());

            Console.WriteLine(i1.Random());

        }
    }

    public static class StringHelper
    {
        public static bool IsCapitalized(this string s)
        {
            return (char.IsUpper(s[0]));
        }

        public static string Pluralize(this string s)
        {
            return s + "'s";
        }
    }



    public static class IntHelper
    {
        public static int Sqr(this int i)
        {
            return i * i;
        }

        public static int Random(this int max, int min = 1)
        {
            Random random = new Random();
            return random.Next(min, max + 1);
        }

      
    }
}
