﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class ValueRefrence
    {
        public static void Execute()
        {
            int i1 = 10; 
            int i2 = i1;

            i1 = 12;

            Console.WriteLine("value type {0}", i2);

            int[] a1 = new int[] { 1, 2, 3 };
            int[] a2 = a1;
            a1[1] = 4;
            Console.WriteLine("refrence type {0}", a2[1]);

            Point p = new Point(10, 12);
            p.Write();

            Point p1 = p;
            p.x = 20;
            p1.Write();
            p.Write();
        }

        struct Point
        {
            public int x;
            public int y;

            public Point(int x, int y)
            {
                this.x = x;
                this.y = y;
            }

            public void Write()
            {
                Console.WriteLine("{0} - {1}", x, y);
            }
        }
    }
}
