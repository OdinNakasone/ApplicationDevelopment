﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Inheritance 
    {
        public static void Execute()
        {
            Animal animal = new Mammal("Panda", 34, 2);
            animal.Speak();
            (animal as Mammal).NumOffspring = 4;
            if(animal is Mammal mammal)
            {
                mammal.NumOffspring = 6;
            }
            Console.WriteLine(animal.ToString());

            Animal reptile = new Reptile("Lizard", 14, 8, true);
            reptile.Speak();

            Animal[] animals = new Animal[] {new Mammal("cat", 18, 7), new Reptile("turtle", 90, 12) };

            foreach(Animal a in animals)
            {
                a.Speak();
                if(a is Mammal mammal1)
                {
                    mammal1.Fly();
                    ((IHunt)mammal1).Hunt();  
                    Console.WriteLine(mammal1.Name);
                }
            }
        }

        abstract class Animal
        {
            protected int lifeSpan;
            public string Name { get; set; }

            public bool Nocturnal { get; }

            public Animal() { }
            public Animal(string name, int lifeSpan, bool nocturnal = false)
            {
                Name = name;
                this.lifeSpan = lifeSpan;
                Nocturnal = nocturnal;
            }

            public abstract void Speak();
            
                
            public string ToString()
            {
                return Name;
            }
        }

        class Mammal : Animal, IFly, IHunt
        {
            public int NumOffspring { get; set; }
            
            public Mammal(string name, int lifeSpan, int numOffSpring, bool nocturnal = false) : base(name, lifeSpan, nocturnal)
            {
                NumOffspring = numOffSpring;
            }

            public override void Speak()
            {
                Console.WriteLine("Mammal Speak!!");
            }

            public void Fly()
            {
                Console.WriteLine("Flying....");
            }
        }

        class Reptile : Animal
        {
            public int NumEggs { get; set; } = 3;

            public Reptile(string name, int lifeSpan, int numEggs, bool nocturnal = false) : base(name, lifeSpan, nocturnal)
            {
                NumEggs = numEggs;
            }

            public override void Speak()
            {
                Console.WriteLine("Reptile Speak!!");
            }
        }
    }
}
