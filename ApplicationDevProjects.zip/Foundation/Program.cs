﻿using System;
using System.Threading.Tasks;
using ConsoleLibrary;

namespace Foundation
{
    class Program
    {
        static void Main(string[] args)
        {
            //DataTypes.Execute();
            //ValueRefrence.Execute();
            //String.Execute();
            //Arrays.Execute();
            //Parameters.Execute();
            //Classes.Execute();
            //IO.Message("Hello");
            //Inheritance.Execute();
            //Generics.Execute();
            //ExtensionMethods.Execute();
            //Null.Execute();
            //Delegates.Execute();
            //Events.Execute();
            //Anonymous.Execute();
            //Tuples.Execute();
            //LINQ.Execute();
            Async.ExecuteASync();
            Task.Delay(3000).Wait();
            Async.Execute();
            //int result;
            //bool success;
            //do
            //{
            //success = int.TryParse(Console.ReadLine(), out result);
            //} while (!success);


            //if(success)
            //{
            //IO.Message($"{result}");
            //}
            //Console.WriteLine("Hello World!");
            //Console.Write("Enter your name: ");
            //string str = Console.ReadLine();
            //Console.WriteLine("Hello " + str + " it's nice to meet you.");

            //IO.GetConsoleInt("Please enter a number between 1 - 10", 1, 10);
            //IO.GetConsoleFloat("Please enter a number between 1.0 - 10.0", 1.0f, 10.0f);
            //IO.GetConsoleBool("Please enter true or false");
            //IO.GetConsoleChar("Please enter a char value");
            //IO.GetConsoleString("Please enter anything");
            //string[] menu = { "Open", "Close", "Quit" };
            //IO.GetConsoleMenu(menu);

        }
    }
}
