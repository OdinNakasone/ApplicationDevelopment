﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Null
    {
        public static void Execute()
        {
            string s = null;
            s = new string("Neumont");
            string s1 = s;
            s = null;
            s = s ?? "nothing";
            Console.WriteLine(s?.Length);

            int? i = null;
            i = 5;
            Console.WriteLine("Has value {0}", i.HasValue);

            Nullable<int> i1 = null;
        }
    }
}
