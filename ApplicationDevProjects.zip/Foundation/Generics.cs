﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Generics
    {

        public static void Execute()
        {
            int v1 = 5;
            int v2 = 12;

            float f1 = 2.3f;
            float f2 = 5.4f;

            Swap(ref f1, ref f2);
            Swap(ref v1, ref v2);

            Stack<float> stack = new Stack<float>();
            stack.Push(10.1f);
            stack.Push(12.4f);

            Console.WriteLine(stack.Pop());
            Console.WriteLine(stack.Pop());
        }

        static void Swap<T>(ref T v1, ref T v2) where T : struct
        {
            T temp = v1;
            v1 = v2;
            v2 = temp;
        }

        class Stack<T>
        {
            int index = 0;
            T[] elements = new T[100];

            public void Push(T element) { elements[index++] = element; }

            public T Pop() { return elements[--index]; }
        }

        class IntStack : Stack<int>
        {

        }
    }
}
