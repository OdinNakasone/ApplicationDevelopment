﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation
{
    class Arrays
    {
        public static void Execute()
        {
            int[] a1 = new int[3];
            a1[0] = 23;
            a1.SetValue(100, 1);
            int[] a2 = { 1, 2, 3, 4 };
            int[] a3 = { 1, 2, 3, 4 };

            for (int i = 0; i < a1.Length; i++) 
            {
                Console.Write($"{a1[i]} ");
            }
            Console.WriteLine();

            foreach (int i in a1)
            {
                Console.Write($"{i} ");
            }
            Console.WriteLine();

            WriteArray(a2);

            //array of objects
            object[] objects = { "Neumont", 5, 3.14f };
            for(int i = 0; i < objects.Length; i++)
            {
                Console.WriteLine("{0} : {1}", objects[i], objects[i].GetType());
            }

            //multi-dimensional arrays
            string[,] multi = new string[2, 2] { { "A", "B" }, { "C", "D" } };
            for(int i = 0; i < multi.GetLength(0); i++)
            {
                for(int j = 0; j < multi.GetLength(1); j++)
                {
                    Console.Write("{0} ", multi[i, j]);
                }
                Console.WriteLine();
            }

            //jagged array
            int[][] jagged = new int[3][];
            jagged[0] = new int[] { 1, 2, 3 };
            jagged[1] = new int[] { 1, 2, 3, 4, 5 };
            jagged[2] = new int[] { 1, 2 };

           

            //sort , reverse
            int[] numbers = new int[] { 1, 3, 54, 23, 5 };
            WriteArray(numbers);

            //slice
            WriteArray(numbers[..3]);
            WriteArray(numbers[2..3]);
            WriteArray(numbers[2..]);

            Index end = ^2;
            WriteArray(numbers[..^2]);

            Console.WriteLine("{0}", numbers[^1]);

            Array.Sort(numbers);
            WriteArray(numbers);

            Array.Reverse(numbers);
            WriteArray(numbers);

            Console.WriteLine("Index of (5): {0}", Array.IndexOf(numbers, 5));

           
        }

        static void WriteArray(int[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                Console.Write($"{values[i]} ");
            }
            Console.WriteLine();
        }
    }
}
