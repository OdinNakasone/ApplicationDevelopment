﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Media;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MatchGame.UserControls
{
    /// <summary>
    /// Interaction logic for Card.xaml
    /// </summary>
    /// 


    public partial class Card : UserControl, INotifyPropertyChanged
    {        
        public Card()
        {
            InitializeComponent();
            DataContext = this;
            this.Loaded += Card_Loaded;
        }

        private void Card_Loaded(object sender, RoutedEventArgs e)
        {
            Owner = (GameWindow)Window.GetWindow(this);
            Owner.RegisterCard(this);
        }

        

        private void btnCard_Click(object sender, RoutedEventArgs e)
        {  
            SoundPlayer player = new SoundPlayer("C:\\Neumont Year 2\\Q2\\Application Dev\\CSC160\\MatchGame\\Resources\\card.wav");
            player.PlaySync();
            State = eState.Flipped;
            Owner.SelectCard(this);
        }

        

        public GameWindow Owner { get; set; }
        private eState state = eState.Inactive;

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged( string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public eState State { get { return state; } 
            set
            {
                if(value != state)
                {
                    state = value;
                    Interactable = (state == eState.Idle);
                    Show = (state == eState.Flipped || state == eState.Matched);

                    NotifyPropertyChanged("State");
                }
            } 
        }

        public bool Show { 
            set
            {
                if(value)
                {
                    lblSymbol.Visibility = Visibility.Visible;
                    imgCard.Visibility = Visibility.Hidden;
                }
                else
                {
                    lblSymbol.Visibility = Visibility.Hidden;
                    imgCard.Visibility = Visibility.Visible;
                }
            }
        }

        private bool interactable;

        public bool Interactable { 
            get
            {
                return interactable;
            }
            set
            {
                if(value != interactable)
                {
                    interactable = value;
                    NotifyPropertyChanged("interactable");
                }
            }
        }

        private string symbol;
        public string Symbol
        {
            get
            {
                return symbol;
            }
            set
            {
                if(value != symbol)
                {
                    symbol = value;
                    NotifyPropertyChanged("symbol");
                }
            }
        }
    }

    public enum eState
    {
        Inactive,
        Idle,
        Flipped,
        Matched
    }
}
