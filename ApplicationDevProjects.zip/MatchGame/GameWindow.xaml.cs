﻿using MatchGame.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MatchGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
    {
        private Random rng = new Random();
        private DispatcherTimer timer = new DispatcherTimer();
        private List<Card> cards = new List<Card>();
        public int numTries = 0;
        public int maxTries = 5;
        public int numMatches = 0;
        
       



        private List<string> symbols = new List<string>()
        {
            "!", "!", "N", "N", ",", ",",
            "b", "b", "v", "v", "w", "w"
        };

        private Card card1 = null;
        private Card card2 = null;


        public GameWindow()
        {
            InitializeComponent();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += TimerTick;            
        }

        public void RegisterCard(Card card)
        {
            card.State = eState.Idle;
            int r = rng.Next(symbols.Count);
            card.Symbol = symbols[r];
            symbols.RemoveAt(r);
            cards.Add(card);
        }

        public void SelectCard(Card card)
        {
            int maxMatches = cards.Count / 2;
            if (card1 == null)
            {
                card1 = card;
            }
            else
            {
                card2 = card;

                if (card1.Symbol == card2.Symbol)
                {
                    numMatches++;
                    card1.State = eState.Matched;
                    card2.State = eState.Matched;
                    card1.IsEnabled = false;
                    card2.IsEnabled = false;
                    card1 = null;
                    card2 = null;

                }
                else
                {


                    foreach (Card cardState in cards)
                    {
                        if (cardState.State == eState.Idle)
                        {
                            cardState.State = eState.Inactive;
                        }
                    }
                    timer.Start();
                    numTries++;
                }

            }
            txtGuesses.Text = "You have " + numTries + " out of " + maxTries + " tries";

            if (numTries >= maxTries)
            {

                MessageBox.Show("Sorry you lost. Try Again!");
                

            }
            else if (numTries < maxTries && numMatches == maxMatches)
            {
                MessageBox.Show("Congrats you won!");
            }

            //foreach(Card winCard in cards)
            //{

            //    if(winCard.State == eState.Matched && winCard.State == eState.Flipped)
            //    {
            //         matchCount++;
            //        if(matchCount == cards.Count && numTries < maxTries)
            //        {
            //            MessageBox.Show("Congrats you won!");
            //            txtGuesses.Text = "Stop guessing already";   
            //        }
            //        else if(matchCount != cards.Count && numTries >= maxTries)
            //        {
            //            MessageBox.Show("Sorry you lost. Try Again!");
            //            txtGuesses.Text = "Stop guessing already";
            //        }
            //    }
            //}

        }

        private void TimerTick(object sender, EventArgs e)
        {
            timer.Stop();
            foreach (Card card in cards)
            {
                if (card.State != eState.Matched)
                {
                    card.State = eState.Idle;

                }

            }
            card1 = null;
            card2 = null;
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            foreach (Card card in cards)
            {
                symbols.Clear();
                card.State = eState.Idle;
                card.IsEnabled = true;
                numTries = 0;
                numMatches = 0;
                txtGuesses.Text = "";
            }
        }
    }
}
