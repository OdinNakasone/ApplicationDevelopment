﻿using System;

namespace ConsoleLibrary
{
    public static class IO
    {
        public static void Message(string str)
        {
            Console.WriteLine(str);
        }

        public static int GetConsoleInt(string message, int min, int max)
        {
            int num;
            bool valid = false;
            do
            {
                Console.WriteLine(message);
                bool success = int.TryParse(Console.ReadLine(), out num);
                valid = success & num >= min & num <= max;
            } while (!valid);

            return num;
        }

        public static float GetConsoleFloat(string message, float min, float max)
        {
            float num;
            bool valid = false;
            do
            {
                Console.WriteLine(message);
                bool success = float.TryParse(Console.ReadLine(), out num);
                valid = success & num >= min & num <= max;
            } while (!valid);

            return num;
        }

        public static bool GetConsoleBool(string message)
        {
            bool input;
            bool valid = false;
            do
            {
                Console.WriteLine(message);
                bool success = bool.TryParse(Console.ReadLine(), out input);
                valid = success & input == false || input == true;
            } while (!valid);

            return input;
        }

        public static char GetConsoleChar(string message)
        {
            char input;
            bool valid = false;
            do
            {
                Console.WriteLine(message);
                bool success = char.TryParse(Console.ReadLine(), out input);
                valid = success;
            } while (!valid);

            return input;
        }

        public static string GetConsoleString(string message)
        {
            Console.WriteLine(message);
            string input = Console.ReadLine();
            return input;
        }

        public static int GetConsoleMenu(string[] items)
        {
            int input;
            for (int i = 0; i < items.Length; i++)
            {
                Console.WriteLine(" " + (i + 1) + " " + items[i]);
            }
            input = GetConsoleInt("Enter Menu selection:", 1, items.Length);

            return input;
        }

    }
}
