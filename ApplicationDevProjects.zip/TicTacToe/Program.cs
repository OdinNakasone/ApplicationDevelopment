﻿using System;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {

            char[,] board = new char[3, 3];
            string[] names = { "Player1", "Player2" };
            char[] symbols = { 'X', 'O' };
            int turn = 0;
            int moves = 0;


            bool done = false;
            do
            {

                displayBoard(board);

                int row = GetInt($"{names[turn]} enter row (1-3): ", 1, 3);

                int column = GetInt($"{names[turn]} enter column (1-3): ", 1, 3);

                board[row - 1, column - 1] = symbols[turn];

                done = CheckForWinner(board, symbols[turn], names, turn);
                moves++;

                if (moves >= 9)
                {
                    if (!done)
                    {
                        done = true;
                        displayBoard(board);
                        Console.WriteLine("It's a cat's game. Try Again next time");
                    }
                }

                turn++;
                turn = turn % 2;



            } while (!done);
        }

        static int GetInt(string prompt, int min, int max)
        {
            int row;
            bool valid = false;
            do
            {
                Console.Write(prompt);
                bool success = int.TryParse(Console.ReadLine(), out row);
                valid = success & row >= min & row <= max;
            } while (!valid);

            return row;
        }

        static void displayBoard(char[,] board)
        {
            Console.WriteLine();
            for (int r = 0; r < board.GetLength(0); r++)
            {
                for (int c = 0; c < board.GetLength(1); c++)
                {
                    Console.Write(" {0}", board[r, c]);
                    if (c < board.GetLength(1) - 1)
                    {
                        Console.Write(" | ");
                    }
                }
                Console.WriteLine();
                if (r < board.GetLength(0) - 1)
                {
                    Console.WriteLine("----------");
                }

            }
            Console.WriteLine();
        }

        static bool CheckForWinner(char[,] board, char symbol, string[] names, int turn)
        {

            //Horizontal Check
            for (int r = 0; r < board.GetLength(0); r++)
            {
                int horizontalCount = 0;
                for (int c = 0; c < board.GetLength(1); c++)
                {

                    if (symbol == board[r, c])
                    {
                        horizontalCount++;
                    }
                    if (horizontalCount == 3)
                    {
                        displayBoard(board);
                        Console.WriteLine($"Congratulations {names[turn]}! You are declared the Winner");
                        return true;
                    }

                }

            }

            //Vertical Check
            for (int c = 0; c < board.GetLength(1); c++)
            {
                int verticalCount = 0;
                for (int r = 0; r < board.GetLength(0); r++)
                {

                    if (symbol == board[r, c])
                    {
                        verticalCount++;
                    }
                    if (verticalCount == 3)
                    {
                        displayBoard(board);
                        Console.WriteLine($"Congratulations {names[turn]}! You are declared the Winner");
                        return true;
                    }
                }

            }

            //Diagonal
            if (board[0, 0] == symbol && board[1, 1] == symbol && board[2, 2] == symbol)
            {
                displayBoard(board);
                Console.WriteLine($"Congratulations {names[turn]}! You are declared the Winner");
                return true;
            }

            //Inverse Diagonal
            if (board[0, 2] == symbol && board[1, 1] == symbol && board[2, 0] == symbol)
            {
                displayBoard(board);
                Console.WriteLine($"Congratulations {names[turn]}! You are declared the Winner");
                return true;
            }



            return false;
        }
    }
}
