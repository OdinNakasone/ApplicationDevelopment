﻿namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database
{
}

namespace Database.DataSetTableAdapters {
    
    
    public partial class GameTableAdapter {
    }
}
