﻿using Database.DataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Database
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        private UsersTableAdapter users = new UsersTableAdapter();
        private DataSet dataSet = new DataSet();

        public Login()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            users.Fill(dataSet.Users);
            DataContext = dataSet.Users.DefaultView;
        }

       

        private void SubmitCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = txtName.Text.Length > 0 && txtPassword.Text.Length > 0;
        }

        private void SubmitCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            DataSet.UsersDataTable usersRows = dataSet.Users; //get IEnumerable to query

            var result = from u in usersRows
                         select u;

            foreach (var user in result)
            {
                bool exists = result.Any(user => user.Name == txtName.Text && user.Password == txtPassword.Text);
                if (exists)
                {
                    MainWindow mainWindow = new MainWindow();
                    Login login = new Login();
                    mainWindow.Show();
                    login.Close();
                    break;

                }
                else
                {
                    MessageBox.Show("Invalid Username/Password", "Error Message", MessageBoxButton.OK, MessageBoxImage.Error);
                    txtName.Text = "";
                    txtPassword.Text = "";
                    break;
                }
            }
        }

        private void RegisterCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = txtName.Text.Length > 0 && txtPassword.Text.Length > 0;
        }

        private void RegisterCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            DataSet.UsersRow row = (DataSet.UsersRow)dataSet.Users.NewRow();
            row.Name = txtName.Text;
            row.Password = txtPassword.Text;

            dataSet.Users.AddUsersRow(row);
            users.Update(dataSet);

            MessageBox.Show("You were Sucessfully Registered", "Register", MessageBoxButton.OK, MessageBoxImage.Information);

            txtName.Text = "";
            txtPassword.Text = "";
        }
    }
}
