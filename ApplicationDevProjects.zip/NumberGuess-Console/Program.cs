﻿using System;
using ConsoleLibrary;
namespace NumberGuess_Console
{
    class Program
    {
        static string[] difficulty = { "Easy (1-10)", "Medium (1-50)", "Hard (1-100)", "Quit Program" };
        static string[] playAgain = { "Yes", "No" };


        static Random rng = new Random();
        static int randNum;
        static int winCount = 0;
        static int attempts = 5;

        static bool done = true;
        static void Main(string[] args)
        {
            if (Console.BackgroundColor == ConsoleColor.Black)
            {
                Console.BackgroundColor = ConsoleColor.Cyan;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.Clear();
            }

            string greeting = "Welcome to a Number Guessing Game!\nPlease Enter your Selection:";
            Console.WriteLine(greeting);

            do
            {
                attempts = 5;
                int selection = IO.GetConsoleMenu(difficulty);
                Console.WriteLine("\nWins: {0}", winCount);
                switch (selection)
                {
                    case 1:

                        GenerateEasyDifficulty();

                        break;
                    case 2:
                        GenerateMediumDiffculty();
                        break;
                    case 3:
                        GenerateHardDifficulty();
                        break;
                    case 4:
                        done = true;
                        break;
                }

            } while (!done);

        }
        static void GenerateEasyDifficulty()
        {
            
            Console.WriteLine("To make checking easier: {0}", randNum);
            do
            {
                int guess = IO.GetConsoleInt("Enter a Value between 1 - 10", 1, 10);
                if (guess == randNum)
                {
                    Console.WriteLine("Congratulations!! The correct answer was {0} and you guessed it in {1} tries!", randNum, attempts);
                    Console.WriteLine("\nDo you want to play again?");
                    int play = IO.GetConsoleMenu(playAgain);
                    winCount++;
                    if (play == 1)
                    {

                        Console.Clear();
                        done = false;
                        break;


                    }
                    else
                    {
                        done = true;
                        break;
                    }
                }
                else if (guess > randNum)
                {
                    Console.Beep(440, 500);
                    attempts--;
                    Console.WriteLine("Your guess was too high try again! \nAttempts: {0}", attempts);


                }
                else if (guess < randNum)
                {
                    Console.Beep(220, 500);
                    attempts--;
                    Console.WriteLine("Your guess was too low try again! \nAttempts: {0}", attempts);


                }
                if (attempts <= 0)
                {
                    Console.WriteLine("Sorry the correct answer was {0}. Game Over!", randNum);
                    Console.WriteLine("\nDo you want to play again?");
                    int play = IO.GetConsoleMenu(playAgain);

                    if (play == 1)
                    {

                        Console.Clear();
                        done = false;

                    }
                    else
                    {
                        done = true;
                    }

                }
            } while (attempts != 0);
        }

        static void GenerateMediumDiffculty()
        {
            randNum = rng.Next(1, 50);
            Console.WriteLine("To make checking easier: {0}", randNum);
            do
            {
                int guess = IO.GetConsoleInt("Enter a Value between 1 - 50", 1, 50);
                if (guess == randNum)
                {
                    Console.WriteLine("Congratulations!! The correct answer was {0} and you guessed it in {1} tries!", randNum, attempts);
                    Console.WriteLine("\nDo you want to play again?");
                    int play = IO.GetConsoleMenu(playAgain);
                    winCount++;
                    if (play == 1)
                    {

                        Console.Clear();
                        done = false;
                        break;


                    }
                    else
                    {
                        done = true;
                        break;
                    }
                }
                else if (guess > randNum)
                {
                    Console.Beep(440, 500);
                    attempts--;
                    Console.WriteLine("Your guess was too high try again! \nAttempts: {0}", attempts);


                }
                else if (guess < randNum)
                {
                    Console.Beep(220, 500);
                    attempts--;
                    Console.WriteLine("Your guess was too low try again! \nAttempts: {0}", attempts);


                }
                if (attempts <= 0)
                {
                    Console.WriteLine("Sorry the correct answer was {0}. Game Over!", randNum);
                    Console.WriteLine("\nDo you want to play again?");
                    int play = IO.GetConsoleMenu(playAgain);

                    if (play == 1)
                    {

                        Console.Clear();
                        done = false;

                    }
                    else
                    {
                        done = true;
                    }

                }
            } while (attempts != 0);
        }

        static void GenerateHardDifficulty()
        {
            randNum = rng.Next(1, 100);
            Console.WriteLine("To make checking easier: {0}", randNum);
            do
            {
                int guess = IO.GetConsoleInt("Enter a Value between 1 - 100", 1, 100);
                if (guess == randNum)
                {
                    Console.WriteLine("Congratulations!! The correct answer was {0} and you guessed it in {1} tries!", randNum, attempts);
                    Console.WriteLine("\nDo you want to play again?");
                    int play = IO.GetConsoleMenu(playAgain);
                    winCount++;
                    if (play == 1)
                    {

                        Console.Clear();
                        done = false;
                        break;


                    }
                    else
                    {
                        done = true;
                        break;
                    }
                }
                else if (guess > randNum)
                {
                    Console.Beep(440, 500);
                    attempts--;
                    Console.WriteLine("Your guess was too high try again! \nAttempts: {0}", attempts);


                }
                else if (guess < randNum)
                {
                    Console.Beep(220, 500);
                    attempts--;
                    Console.WriteLine("Your guess was too low try again! \nAttempts: {0}", attempts);


                }
                if (attempts <= 0)
                {
                    Console.WriteLine("Sorry the correct answer was {0}. Game Over!", randNum);
                    Console.WriteLine("\nDo you want to play again?");
                    int play = IO.GetConsoleMenu(playAgain);

                    if (play == 1)
                    {

                        Console.Clear();
                        done = false;

                    }
                    else
                    {
                        done = true;
                    }

                }
            } while (attempts != 0);
        }

    }
}
