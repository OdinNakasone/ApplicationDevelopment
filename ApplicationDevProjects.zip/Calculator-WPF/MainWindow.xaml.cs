﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        float number1;
        float number2;
        float answer;

        int negativeCount = 0;
        int decimalCount = 0;
        int zeroCount = 0;

        bool addWasClicked = false;
        bool subWasClicked = false;
        bool multWasClicked = false;
        bool divWasClicked = false;

        public MainWindow()
        {
            InitializeComponent();
            inputBox.Text = "";
        }

        private void input1_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "1";

        }

        private void input2_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "2";
        }

        private void input3_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "3";
        }

        private void input4_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "4";
        }

        private void input5_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "5";
        }

        private void input6_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "6";
        }

        private void input7_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "7";
        }

        private void input8_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "8";
        }

        private void input9_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = inputBox.Text + "9";
        }

        private void input0_Click(object sender, RoutedEventArgs e)
        {
           
            if (zeroCount == 0)
            {
                inputBox.Text = inputBox.Text + "0";
                zeroCount++;
            }
            else if (zeroCount == 1)
            {
                inputBox.Text = inputBox.Text.Replace("0", "").Trim();
                zeroCount--;
            }
        }

        private void inputPlus_Click(object sender, RoutedEventArgs e)
        {
            addWasClicked = true;
            subWasClicked = false;
            multWasClicked = false;
            divWasClicked = false;
            try
            {
                number1 = float.Parse(inputBox.Text);
            }catch(Exception ex)
            {
               
            }
            
            inputBox.Text = "";
        }

        private void inputMinus_Click(object sender, RoutedEventArgs e)
        {
            addWasClicked = false;
            subWasClicked = true;
            multWasClicked = false;
            divWasClicked = false;
            try
            {
                number1 = float.Parse(inputBox.Text);
            }
            catch (Exception ex)
            {

            }
            inputBox.Text = "";
        }

        private void inputMultiply_Click(object sender, RoutedEventArgs e)
        {
            addWasClicked = false;
            subWasClicked = false;
            multWasClicked = true;
            divWasClicked = false;
            try
            {
                number1 = float.Parse(inputBox.Text);
            }
            catch (Exception ex)
            {

            }
            inputBox.Text = "";
        }

        private void inputDivision_Click(object sender, RoutedEventArgs e)
        {
            addWasClicked = false;
            subWasClicked = false;
            multWasClicked = false;
            divWasClicked = true;
            try
            {
                number1 = float.Parse(inputBox.Text);
            }
            catch (Exception ex)
            {

            }
            inputBox.Text = "";
        }
        private void inputSquare_Click(object sender, RoutedEventArgs e)
        {
            addWasClicked = false;
            subWasClicked = false;
            multWasClicked = false;
            divWasClicked = false;
            try
            {
                number1 = float.Parse(inputBox.Text);
            }
            catch (Exception ex)
            {

            }
            float sqr = number1 * number1;
            inputBox.Text = sqr.ToString();
        }

        private void inputEquals_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                number2 = float.Parse(inputBox.Text);
            }
            catch (Exception ex)
            {

            }
            if (addWasClicked)
            {
                answer = number1 + number2;
            }
            else if(subWasClicked)
            {
                answer = number1 - number2;
            }
            else if (multWasClicked)
            {
                answer = number1 * number2;
            }
            else if(divWasClicked)
            {
                answer = number1 / number2;
            }
           
            inputBox.Text = answer.ToString();
        }

        private void inputClear_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = "";
            number1 = 0f;
            number2 = 0f;
            negativeCount = 0;
            decimalCount = 0;
        }

        private void inputClearEntry_Click(object sender, RoutedEventArgs e)
        {
            inputBox.Text = "";
        }

        private void inputPositiveOrNegative_Click(object sender, RoutedEventArgs e)
        {
            
            if(negativeCount == 0)
            {
                inputBox.Text = "-" + inputBox.Text;
                negativeCount++;
            }
            else if(negativeCount == 1)
            { 
                inputBox.Text = inputBox.Text.Replace("-", "").Trim();
                negativeCount--;
            }
        }

        private void inputDecimal_Click(object sender, RoutedEventArgs e)
        {
            if (decimalCount == 0)
            {
                inputBox.Text = inputBox.Text + ".";
                decimalCount++;
            }
            else if (decimalCount == 1)
            {
                inputBox.Text = inputBox.Text.Replace(".", "").Trim();
                decimalCount--;
            }
        }
    }
}
