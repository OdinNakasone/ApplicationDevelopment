﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Devices.Geolocation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Maps;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Map
{

    /// <summary>
    /// Holds location information
    /// </summary>

   public class LocationInfo
    {
        public string Name { get; set; }
        public Geopoint Geopoint { get; set; }
        public Symbol Symbol { get; set; }
    }

    /// <summary>
    /// Holds the current weather information
    /// </summary>
    public class WeatherInfo : INotifyPropertyChanged
    {
        string city;
        public string City { get { return city; } set {if(value != city) { city = value; OnPropertyChanged(); } } }

        string main;
        public string Main { get { return main; } set { if (value != main) { main = value; OnPropertyChanged(); } } }

        string description;
        public string Description { get { return description; } set { if (value != description) { description = value; OnPropertyChanged(); } } }

        string temperature;
        public string Temperature { get { return temperature; } set { if (value != temperature) { temperature = value; OnPropertyChanged(); } } }

        string temperatureLow;
        public string TemperatureLow { get { return temperatureLow; } set { if (value != temperatureLow) { temperatureLow = value; OnPropertyChanged(); } } }

        string temperatureHigh;
        public string TemperatureHigh { get { return temperatureHigh; } set { if (value != temperatureHigh) { temperatureHigh = value; OnPropertyChanged(); } } }



        public event PropertyChangedEventHandler PropertyChanged;

        BitmapImage bitmapImage;
        public BitmapImage BitmapImage { get { return bitmapImage; } set { if (value != bitmapImage) { bitmapImage = value; OnPropertyChanged(); } } }

        void OnPropertyChanged([CallerMemberName]string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public WeatherInfo WeatherInfo { get; set; } = new WeatherInfo();

        ObservableCollection<LocationInfo> locationInfos = new ObservableCollection<LocationInfo>();    
        public MainPage()
        {
            this.InitializeComponent();

            DataContext = this;
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            lstLocations.ItemsSource = locationInfos;
        }


        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            BasicGeoposition basicGeoposition = new BasicGeoposition()
            {
                Latitude = 21.397223,
                Longitude = -157.973328
            };
            Geopoint geopoint = await GetGeoLocation(); //new Geopoint(basicGeoposition);
            Map.Center = geopoint;
            Map.ZoomLevel = 17;
            Map.TrafficFlowVisible = false;

            await UpdateWeatherInfoAsync(geopoint);
        }

        async Task<Geopoint> GetGeoLocation()
        {
            Geopoint geopoint = null;

            if (await Geolocator.RequestAccessAsync() == GeolocationAccessStatus.Allowed)
            {
                Geolocator geolocator = new Geolocator() { DesiredAccuracyInMeters = 1 };

                Geoposition geoposition = await geolocator.GetGeopositionAsync();
                geopoint = geoposition.Coordinate.Point;
            }

            return geopoint;
        }

       async Task UpdateWeatherInfoAsync(Geopoint geopoint)
        {
           WeatherAPI.RootObject rootObject = await WeatherAPI.GetWeatherAsync(geopoint.Position.Latitude, geopoint.Position.Longitude);
            string url = "http://openweathermap.org/img/wn/" + rootObject.weather[0].icon + ".png";

            WeatherInfo.City = rootObject.name;
            WeatherInfo.Main = rootObject.weather[0].main;
            WeatherInfo.Description = rootObject.weather[0].description;
            
            WeatherInfo.BitmapImage = new BitmapImage(new Uri(url, UriKind.Absolute));

            WeatherInfo.Temperature = rootObject.main.temp + "°F  ";
            WeatherInfo.TemperatureLow = rootObject.main.temp_min + "°F  ";
            WeatherInfo.TemperatureHigh = rootObject.main.temp_max + "°F  ";
        }

        private async void Map_MapTapped(Windows.UI.Xaml.Controls.Maps.MapControl sender, Windows.UI.Xaml.Controls.Maps.MapInputEventArgs args)
        {

            LocationContentDialog contentDialog = new LocationContentDialog();
            ContentDialogResult result = await contentDialog.ShowAsync();
            if(result == ContentDialogResult.Primary)
            {
                var position = args.Location.Position;
                position.Altitude = 0;

                Geopoint geopoint = new Geopoint(args.Location.Position);
                contentDialog.LocationInfo.Geopoint = geopoint;
                locationInfos.Add(contentDialog.LocationInfo);


                MapIcon mapIcon = new MapIcon();
                mapIcon.Location = geopoint;
                mapIcon.Title = contentDialog.LocationInfo.Name;

                Map.MapElements.Add(mapIcon);

                Map.Center = geopoint;
                await UpdateWeatherInfoAsync(geopoint);
            }

        }

        private async void lstLocations_ItemClick(object sender, ItemClickEventArgs e)
        {
            if(e.ClickedItem is LocationInfo locationInfo)
            {
                Map.Center = locationInfo.Geopoint;
                await UpdateWeatherInfoAsync(locationInfo.Geopoint);
            }
        }
    }
}
