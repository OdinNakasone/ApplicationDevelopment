﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Game.Objects
{
    class Brick : GameObject
    {
        SoundPlayer player = new SoundPlayer("C:\\Neumont Year 2\\Q2\\Application Dev\\CSC160\\Game\\Resources\\Hit02.wav");
        public enum eType
        {
            B1,
            B2,
            B3,
            Multiplier,
            SPEED
        }

        SolidColorBrush[] colors =
        {
                new SolidColorBrush(Colors.White),
                new SolidColorBrush(Colors.Red),
                new SolidColorBrush(Colors.Orange),
                new SolidColorBrush(Colors.Blue),
                new SolidColorBrush(Colors.Green)
        };
        eType type;
        public Brick(Vector position, Vector size, eType type)
        {
            Shape = new Rectangle();
            Shape.Fill = colors[(int)type];
            Shape.Stroke = new SolidColorBrush(Colors.Black);
            Position = position;
            Size = size;
            this.type = type;
        }

        public override void OnCollison(GameObject gameObject)
        {
            if(gameObject is Ball ball)
            {
                //player.Play();
                ball.Velocity = -ball.Velocity;
                IsDestroyed = true;

                switch (type)
                {
                    case eType.B1:
                        GameManager.GameController.Score += 100;
                        break;
                    case eType.B2:
                        GameManager.GameController.Score += 250;
                        break;
                    case eType.B3:
                        GameManager.GameController.Score += 500;
                        break;
                    case eType.Multiplier:
                        GameManager.GameController.Score += 1000;
                        GameManager.GameController.Score = (int)(GameManager.GameController.Score * 1.5);
                        break;
                    case eType.SPEED:
                        GameManager.GameController.Score += 5000;
                        ball.Velocity = ball.Velocity * 1.25;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
