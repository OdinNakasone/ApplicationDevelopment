﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Game.Objects
{
    class Ball : GameObject
    {
        SoundPlayer player = new SoundPlayer("C:\\Neumont Year 2\\Q2\\Application Dev\\CSC160\\Game\\Resources\\BallLost.wav");
        public Ball(Vector position, Vector velocity, Vector size)
        {
           Shape = new Ellipse();

            SolidColorBrush[] colors = 
            { 
                new SolidColorBrush(Colors.White), 
                new SolidColorBrush(Colors.Red), 
                new SolidColorBrush(Colors.Orange), 
                new SolidColorBrush(Colors.Blue), 
                new SolidColorBrush(Colors.Green) 
            };

           Shape.Fill = colors[new Random().Next(0, colors.Length)];
           Shape.Stroke = new SolidColorBrush(Colors.Black);
           Position = position;
           Velocity = velocity;
            Size = size;
        }
        public override void Update(double dt)
        {
            Vector position = Position;
            Vector velocity = Velocity;

            if(Rect.Left < 0) { velocity.X = -velocity.X; position.X = Size.X * 0.5; }
            if(Rect.Left >  GameManager.Size.X) { velocity.X = -velocity.X; position.X = GameManager.Size.X - Size.X * 0.5; }
            if(Rect.Top < 0) { velocity.Y = -velocity.Y; position.Y = Size.Y * 0.5; }

            //if(Rect.Bottom > GameManager.Size.Y) { velocity.Y = -velocity.Y; position.Y = GameManager.Size.Y - Size.Y * 0.5; }
            if(Rect.Bottom > GameManager.Size.Y) 
            {
                player.Play();
                IsDestroyed = true;
            }

            Velocity = velocity;
            Position = position;

            base.Update(dt);
        }

        public override void OnCollison(GameObject gameObject)
        {
            
        }
    }
}
