﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Game.Objects
{
    class Paddle : GameObject
    {

        SoundPlayer player = new SoundPlayer("C:\\Neumont Year 2\\Q2\\Application Dev\\CSC160\\Game\\Resources\\Hit01.wav");

        public Paddle(Vector position, Vector size)
        {
            Shape = new Rectangle();
            Shape.Fill = new SolidColorBrush(Colors.White);
            Shape.Stroke = new SolidColorBrush(Colors.Black);
            Position = position;
            Size = size;
        }

        public override void Update(double dt)
        {
            Point mousePosition = Mouse.GetPosition(GameManager.Canvas);
            if (mousePosition.X < 0 && mousePosition.Y < 0) return;

            double x = Math.Clamp(mousePosition.X, Size.X * 0.5, GameManager.Size.X - Size.X * 0.5);
            Position = new Vector(x, Position.Y);

            base.Update(dt);
        }
        public override void OnCollison(GameObject gameObject)
        {
            
            
            if (gameObject is Ball ball)
            {
                player.Play();
                //ball.Velocity = -ball.Velocity;
                double dx = ball.Position.X - Position.X;
                dx = dx / (Size.X * 0.5);
                double angle = (Math.PI * 1.5) + dx * (Math.PI * 0.35);

                ball.Velocity = GameObject.AngleToVector(angle, ball.Velocity.Length);
                
               
            }
        }


    }
}
