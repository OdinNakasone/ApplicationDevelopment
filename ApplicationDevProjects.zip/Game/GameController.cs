﻿using Game.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Windows;

namespace Game
{
    class GameController
    {
        public enum eState
        {
            Initialize,
            Title,
            StartLevel,
            StartBall,
            Update,
            EndBall,
            GameOver
        }

        eState state = eState.Initialize;

        public int Score { get; set; }
        public int HighScore { get; set; }
        public int Lives { get; set; }
        public GameManager GameManager { get; set; }
        public MainWindow MainWindow { get; set; }

        double timer;
        SoundPlayer player = new SoundPlayer("C:\\Neumont Year 2\\Q2\\Application Dev\\CSC160\\Game\\Resources\\Start.wav");
        List<int> scores = new List<int>();

        public void Update(double dt)
        {
            switch (state)
            {
                case eState.Initialize:
                    GameManager.AddGameObject(new Paddle(new Vector(GameManager.Size.X * 0.5, GameManager.Size.Y * 0.9), new Vector(40, 10)));
                    state = eState.Title;
                    break;
                case eState.Title:
                    MainWindow.txtTitle.Visibility = Visibility.Visible;         
                    Lives = 3;
                    Score = 0;
                    break;
                case eState.StartLevel:
                    CreateBoard();
                    state = eState.StartBall;
                    break;
                case eState.StartBall:
                    timer += dt;
                    if (timer > 1)
                    {
                        GameManager.AddGameObject(new Ball(new Vector(GameManager.Size.X * 0.5, GameManager.Size.Y * 0.5), GameObject.AngleToVector(new Random().NextDouble() * Math.PI * 2, 200), new Vector(10, 10)));
                        state = eState.Update;
                    }
                    break;
                case eState.Update:
                    if (GameManager.GetCount<Ball>() == 0) state = eState.EndBall;
                    if (GameManager.GetCount<Brick>() == 0) state = eState.StartLevel;
                    break;
                case eState.EndBall:
                    Lives--;
                    timer = 0;
                    state = (Lives == 0) ? eState.GameOver : eState.StartBall;
                    MainWindow.txtLives.Text = "Lives: " + Lives.ToString();
                    break;
                case eState.GameOver:
                    timer += dt;
                    if(timer > 1)
                    {
                        state = eState.Title;
                    }
                    state = eState.Title;
                    scores.Add(Score);
                    MainWindow.txtHighScore.Text = "High Score: " + scores.Max().ToString("D6");
                    MessageBox.Show("Ran out Lives Try again!", "Oops", MessageBoxButton.OK);

                    break;
                default:
                    break;
            }

            MainWindow.txtScore.Text = "Score: " + Score.ToString("D6");
           

            GameManager.Update(dt);
            GameManager.Draw();
        }
        void CreateBoard()
        {
            int[] bricks =
            {
                4,4,4,4,4,4,4,4,4,4,
                2,2,1,1,2,2,1,1,2,2,
                1,1,1,1,1,1,1,1,1,1,
                0,0,0,0,0,0,0,0,0,0
            };

            for (int y = 0; y < 4; y++)
            {
                for (int x = 0; x < 10; x++)
                {
                    GameManager.AddGameObject(new Brick(new Vector(20 + (x * 40), (GameManager.Size.Y * 0.2) + y * 20), new Vector(40, 20), (Brick.eType)bricks[x + (y * 10)]));

                }
            }
        }

        public void OnMouseClick()
        {
           
            if (state == eState.Title)
            {
                MainWindow.txtTitle.Visibility = Visibility.Hidden;
                state = eState.StartLevel;
                MainWindow.txtLives.Text = "Lives: " +  Lives.ToString();
                player.Play();

            }
        }
    }

   
}
