﻿using Game.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace Game
{
    class GameManager
    {
        public Canvas Canvas { get; set; }
        public Vector Size { get { return new Vector(Canvas.ActualWidth, Canvas.ActualHeight); } }

        List<GameObject> gameObjects = new List<GameObject>();
       public GameController GameController { get; set; }

        public void Update(double dt)
        {
            gameObjects.ForEach(gameObject => gameObject.Update(dt));

            //collision
            for (int i = 0; i < gameObjects.Count; i++)
            {
                for (int j = i + 1; j < gameObjects.Count; j++)
                {
                    if(gameObjects[i].Intersects(gameObjects[j]))
                    {
                        gameObjects[i].OnCollison(gameObjects[j]);
                        gameObjects[j].OnCollison(gameObjects[i]);
                    }
                }
            }

            //destroy
            var destroyed = gameObjects.Where(gameObject => gameObject.IsDestroyed).ToList();
            destroyed.ForEach(gameObject => Canvas.Children.Remove(gameObject.Shape));

           gameObjects = gameObjects.Except(destroyed).ToList();
        }

        public void Draw()
        {
            gameObjects.ForEach(gameObject => gameObject.Draw());
        }

        public void AddGameObject(GameObject gameObject)
        {
            gameObject.GameManager = this;
            gameObjects.Add(gameObject);
            Canvas.Children.Add(gameObject.Shape);
        }

        public int GetCount<T>()
        {
            return gameObjects.Count(gameObject => gameObject is T);
        }

        public void DestroyType<T>()
        {
            var destroyed = gameObjects.Where(gameObject => gameObject is T).ToList();
            destroyed.ForEach(gameObject => gameObject.IsDestroyed = true);
        }
    }
}
