﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace Game
{
    class AudioSystem
    {
        static AudioSystem instance;
        public static AudioSystem Instance
        {
            get
            {
                instance = (instance == null) ? new AudioSystem() : instance;
                return instance;
            }
        }

        Dictionary<string, MediaPlayer> sounds = new Dictionary<string, MediaPlayer>();

        public void AddSound(string key, string filename)
        {
            MediaPlayer mediaPlayer = new MediaPlayer();
            mediaPlayer.Open(new Uri(@"Resources\" + filename, UriKind.Relative));
            sounds[key] = mediaPlayer;
        }

        public void PlaySound(string key)
        {
            sounds[key].Stop();
            sounds[key].Play();
        }
    }
}
