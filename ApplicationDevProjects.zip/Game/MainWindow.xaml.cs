﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Game.Objects;

namespace Game
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer = new DispatcherTimer();
        DateTime prevTime = new DateTime();
        Random random = new Random();

        GameManager gameManager = new GameManager();
        GameController game = new GameController();
       
        public MainWindow()
        {
            InitializeComponent();

            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            gameManager.Canvas = cnvGame;
            gameManager.GameController = game;
            game.GameManager = gameManager;
            game.MainWindow = this;

            prevTime = DateTime.Now;
        }
    
        void Timer_Tick(object sender, EventArgs e)
        {
            TimeSpan timeSpan = DateTime.Now - prevTime;
            prevTime = DateTime.Now;

            double dt = timeSpan.TotalSeconds;
            game.Update(dt);
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            
            game.OnMouseClick();
           
        }
    }
}
